import io 
import json
import pandas as pd
import oci
import base64
import logging
import requests
from fdk import response
from oci.auth.signers import get_resource_principals_signer
from requests.auth import HTTPBasicAuth
def handler(ctx, data: io.BytesIO = None):
    try:
        
        secret=get_password()

        event_data = json.load(data)
        logging.getLogger().info("Successfully load json data for vm")
        logging.getLogger().info(f"Event type is {event_data.get('eventType')}")
        url = 'https://cloudeqincdemo1.service-now.com/api/cloud/oci/events/cmdb'
        username = 'svc_oci_cmdb'
        password = secret 
        payload = {"oci_response" : event_data}
        result = requests.post(url, auth=HTTPBasicAuth(username, password), json=payload)
        if result.status_code == 200:
            logging.getLogger().info("Successfully send the data to snow")
        else:
            logging.getLogger().info('Error in sending this response to ServiceNow.')
 
   
    except (Exception, ValueError) as ex:
        logging.getLogger().error(f"Error processing event: {ex}")
        return response(f"Error: {ex}", 500)

 
def get_password():
    # Initialize OCI client with resource principal signer
    signer = get_resource_principals_signer()
    vault_client = oci.secrets.SecretsClient({}, signer=signer)
    snow_password='ocid1.vaultsecret.oc1.ap-mumbai-1.amaaaaaabfgevmaafkby6j464chhpjndue3bukokppsg5swxjova5gkp7sfa'
    secret_id_list=[snow_password]
    for secret_id in secret_id_list:
        secret_bundle = vault_client.get_secret_bundle(secret_id).data
        db_pass = secret_bundle.secret_bundle_content.content
        
        decoded_bytes=base64.b64decode(db_pass)
        plain_text = decoded_bytes.decode('utf-8')
        # logging.getLogger().info(plain_text)
    return plain_text

    
 
